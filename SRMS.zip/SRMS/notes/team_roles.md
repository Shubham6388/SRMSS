# Suggested Team Roles (6 members)
1. Project Manager - coordinates tasks, deadlines, demos.
2. Backend Lead - implements Servlets/DAO/DB schema.
3. Frontend Lead - implements JSP, HTML, CSS, basic JS.
4. Database Admin - sets up MySQL, provides sample data, backup.
5. QA & Testing - creates test cases and verifies CRUD flows.
6. Documentation & Deployment - prepares README, deploys to Tomcat.
